#ifndef ISL_VERSION_H
#define ISL_VERSION_H

#if defined(__cplusplus)
extern "C" {
#endif

const char *isl_version(void);

#if defined(__cplusplus)
}
#endif

#endif
